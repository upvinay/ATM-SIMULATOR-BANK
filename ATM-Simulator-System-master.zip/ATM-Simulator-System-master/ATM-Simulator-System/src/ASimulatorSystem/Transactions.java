package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Transactions extends JFrame implements ActionListener {

    JLabel l1;
    JButton b1, b2, b3, b4, b5, b6, b7, b8;
    String pin, acno;

    Transactions(String pin, String acno) {
        this.pin = pin;
        this.acno = acno;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l2 = new JLabel(i3);
        l2.setBounds(0, 0, 750, 580);
        add(l2);

        l1 = new JLabel("Please Select Your Transaction");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));

        b1 = new JButton("DEPOSIT");
        b2 = new JButton("CASH WITHDRAWL");
        b3 = new JButton("FAST CASH");
        b4 = new JButton("MINI STATEMENT");
        b5 = new JButton("PIN CHANGE");
        b6 = new JButton("BALANCE ENQUIRY");
        b7 = new JButton("EXIT");
        b8 = new JButton("Log Out");

        setLayout(null);

        l1.setBounds(130, 110, 700, 35);
        l2.add(l1);

        b1.setBounds(70, 190, 150, 35);
        l2.add(b1);

        b2.setBounds(270, 190, 150, 35);
        l2.add(b2);

        b3.setBounds(70, 250, 150, 35);
        l2.add(b3);

        b4.setBounds(270, 250, 150, 35);
        l2.add(b4);

        b5.setBounds(70, 310, 150, 35);
        l2.add(b5);

        b6.setBounds(270, 310, 150, 35);
        l2.add(b6);

        b7.setBounds(135, 370, 100, 35);
        l2.add(b7);

        b8.setBounds(255, 370, 100, 35);
        l2.add(b8);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);
        b8.addActionListener(this);

        String query2 = "select * from login where pin = '" +1234+ "'";
        try {
            Conn c1 = new Conn();
            ResultSet rs1 = c1.s.executeQuery(query2);
            while (rs1.next()) {
                acno = (rs1.getString("acno"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        setSize(750, 580);
        setLocation(240, 60);
        setUndecorated(true);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            setVisible(false);
            new Deposit(pin, acno).setVisible(true);
        } else if (ae.getSource() == b2) {
            setVisible(false);
            new Withdrawl(pin, acno).setVisible(true);
        } else if (ae.getSource() == b3) {
            setVisible(false);
            new FastCash(pin, acno).setVisible(true);
        } else if (ae.getSource() == b4) {
            new MiniStatement(pin, acno).setVisible(true);
        } else if (ae.getSource() == b5) {
            setVisible(false);
            new Pin(pin, acno).setVisible(true);
        } else if (ae.getSource() == b6) {
            this.setVisible(false);
            new BalanceEnquiry(pin, acno).setVisible(true);
        } else if (ae.getSource() == b7) {
            System.exit(0);
        } else if (ae.getSource() == b8) {
            this.setVisible(false);
            new Login().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new Transactions("", "").setVisible(true);
    }
}
