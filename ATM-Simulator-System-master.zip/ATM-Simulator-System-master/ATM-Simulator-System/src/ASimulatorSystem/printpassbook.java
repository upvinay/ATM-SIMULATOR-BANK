package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.awt.print.*;

public class printpassbook extends JFrame implements ActionListener {

    JLabel l1, l2, l3, n, ac, i, d, a, bc, bc1, ag, ig, ng, acg, dg, acg1;
    JButton b1, b3;
    int fng;
    String r, acno;
    JLabel passbookPanel; 

    printpassbook(String acno) {
        this.acno = acno;
        setTitle("mPassBook");

        l1 = new JLabel("Here is your PassBook:");
        l1.setFont(new Font("Osward", Font.BOLD, 22));
        l1.setForeground(Color.BLACK);
        l1.setBounds(10, 0, 280, 28);
        add(l1);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/formatpassbook.png"));
        Image i2 = i1.getImage().getScaledInstance(580, 480, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        passbookPanel = new JLabel(i3);
        passbookPanel.setBounds(90, 40, 580, 480);
        add(passbookPanel);

        bc1 = new JLabel("Your Trust, Our Priority");
        bc1.setFont(new Font("Times New Roman", Font.BOLD, 28));
        bc1.setForeground(Color.BLUE);
        bc1.setBounds(130, 244, 700, 30);
        passbookPanel.add(bc1);

        bc = new JLabel("Branch: Bhabua");
        bc.setFont(new Font("Osward", Font.BOLD, 18));
        bc.setForeground(Color.yellow);
        bc.setBounds(200, 274, 700, 30);
        passbookPanel.add(bc);

        n = new JLabel("Name:");
        n.setFont(new Font("Osward", Font.BOLD, 18));
        n.setForeground(Color.black);
        n.setBounds(120, 310, 700, 30);
        passbookPanel.add(n);

        ac = new JLabel("Account Number:");
        ac.setFont(new Font("Osward", Font.BOLD, 18));
        ac.setForeground(Color.black);
        ac.setBounds(22, 340, 700, 30);
        passbookPanel.add(ac);

        i = new JLabel("IFSC Code:");
        i.setFont(new Font("Osward", Font.BOLD, 18));
        i.setForeground(Color.black);
        i.setBounds(78, 370, 700, 30);
        passbookPanel.add(i);

        d = new JLabel("D.O.B.:");
        d.setFont(new Font("Osward", Font.BOLD, 18));
        d.setForeground(Color.black);
        d.setBounds(114, 400, 700, 30);
        passbookPanel.add(d);

        a = new JLabel("Aadhaar Number:");
        a.setFont(new Font("Osward", Font.BOLD, 18));
        a.setForeground(Color.black);
        a.setBounds(22, 430, 700, 30);
        passbookPanel.add(a);

        ng = new JLabel();
        ng.setFont(new Font("Osward", Font.BOLD, 18));
        ng.setForeground(Color.black);
        ng.setBounds(210, 310, 700, 30);
        passbookPanel.add(ng);

        acg = new JLabel();
        acg.setFont(new Font("Osward", Font.BOLD, 18));
        acg.setForeground(Color.black);
        acg.setBounds(210, 340, 700, 30);
        passbookPanel.add(acg);

        ig = new JLabel();
        ig.setFont(new Font("Osward", Font.BOLD, 18));
        ig.setForeground(Color.black);
        ig.setBounds(210, 370, 700, 30);
        passbookPanel.add(ig);

        dg = new JLabel();
        dg.setFont(new Font("Osward", Font.BOLD, 18));
        dg.setForeground(Color.black);
        dg.setBounds(210, 400, 700, 30);
        passbookPanel.add(dg);

        ag = new JLabel();
        ag.setFont(new Font("Osward", Font.BOLD, 18));
        ag.setForeground(Color.black);
        ag.setBounds(210, 430, 700, 30);
        passbookPanel.add(ag);

        b1 = new JButton("Print");
        b1.setBackground(Color.green);
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("Arial", Font.BOLD, 14));
        b1.setBounds(600, 0, 100, 30);
        b1.addActionListener(this);
        add(b1);

        b3 = new JButton("BACK");
        b3.setBackground(Color.red);
        b3.setForeground(Color.WHITE);
        b3.setFont(new Font("Arial", Font.BOLD, 14));
        b3.setBounds(10, 510, 80, 30);
        b3.addActionListener(this);
        add(b3);

        setLayout(null);
        r = acno;

        
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from accountdetails where acno = '" + r + "'");
            if (rs.next()) {
                ng.setText(rs.getString("name"));
                acg.setText(rs.getString("acno"));
                ig.setText(rs.getString("ifsc"));
                fng = Integer.parseInt(rs.getString("formno"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

      
        try {
            Conn c1 = new Conn();
            ResultSet rs1 = c1.s.executeQuery("select * from signuptwo where formno = '" + fng + "'");
            while (rs1.next()) {
                ag.setText(rs1.getString("aadhar"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

      
        try {
            Conn c1 = new Conn();
            ResultSet rs1 = c1.s.executeQuery("select * from signup where formno = '" + fng + "'");
            while (rs1.next()) {
                dg.setText(rs1.getString("dob"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        getContentPane().setBackground(Color.WHITE);
        setSize(750, 580);
        setLocation(240, 60);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b3) {
            setVisible(false);
            new Bankhome("").setVisible(true);
        } else if (ae.getSource() == b1) {
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setJobName("Print Passbook");

            job.setPrintable(new Printable() {
                public int print(Graphics g, PageFormat pf, int pageIndex) throws PrinterException {
                    if (pageIndex > 0) {
                        return Printable.NO_SUCH_PAGE;
                    }

                    Graphics2D g2 = (Graphics2D) g;
                    g2.translate(pf.getImageableX(), pf.getImageableY());

                  
                    double scaleX = pf.getImageableWidth() / passbookPanel.getWidth();
                    double scaleY = pf.getImageableHeight() / passbookPanel.getHeight();
                    double scale = Math.min(scaleX, scaleY);
                    g2.scale(scale, scale);

                    passbookPanel.printAll(g2);
                    return Printable.PAGE_EXISTS;
                }
            });

            boolean ok = job.printDialog();
            if (ok) {
                try {
                    job.print();
                } catch (PrinterException ex) {
                    JOptionPane.showMessageDialog(this, "Print Failed: " + ex.getMessage());
                    ex.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) {
        new printpassbook("").setVisible(true);
    }
}
