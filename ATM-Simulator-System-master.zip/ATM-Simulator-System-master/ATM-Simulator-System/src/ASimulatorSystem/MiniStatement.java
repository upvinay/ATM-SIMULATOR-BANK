package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class MiniStatement extends JFrame implements ActionListener {

    JButton b1, b2;
    JLabel l1,l5;

    MiniStatement(String pin, String acno) {
        super("Mini Statement");
        getContentPane().setBackground(Color.WHITE);
        setSize(750, 580);
        setLocation(240, 60);

        l1 = new JLabel();
        add(l1);

        JLabel l2 = new JLabel("Indian Bank");
        l2.setBounds(340, 10, 100, 20);
        add(l2);

        JLabel l3 = new JLabel();
        l3.setBounds(20, 80, 300, 20);
        add(l3);

        JLabel l5 = new JLabel("A/C Number  : " + acno);
        l5.setBounds(420, 80, 300, 20);
        add(l5);

        JLabel l4 = new JLabel();
        l4.setBounds(20, 460, 300, 20);
        add(l4);

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from login where pin = '" + pin + "' and acno='" + acno + "'");
            while (rs.next()) {
                l3.setText("Card Number:    " + rs.getString("cardnumber").substring(0, 4) + "XXXXXXXX" + rs.getString("cardnumber").substring(12));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            int balance = 0;
            Conn c1 = new Conn();

            ResultSet rs1 = c1.s.executeQuery("SELECT * FROM bank where acno = '" + acno + "' ORDER BY date ASC");
            while (rs1.next()) {
                l1.setText(l1.getText() + "<html>" + rs1.getString("date") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs1.getString("type") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rs1.getString("amount") + "<br><br><html>");
                if (rs1.getString("type").equals("Deposit")) {
                    balance += Integer.parseInt(rs1.getString("amount"));
                } else {
                    balance -= Integer.parseInt(rs1.getString("amount"));
                }
            }
            l4.setText("Your total Balance is Rs " + balance);
        } catch (Exception e) {
            System.out.println(e);
        }

        setLayout(null);
        b1 = new JButton("Exit");
        add(b1);

        b1.addActionListener(this);

        l1.setBounds(30, 140, 400, 200);
        b1.setBounds(60, 500, 150, 25);
    }

    public void actionPerformed(ActionEvent ae) {
        this.setVisible(false);
    }

    public static void main(String[] args) {
        new MiniStatement("", "").setVisible(true);
    }

}
