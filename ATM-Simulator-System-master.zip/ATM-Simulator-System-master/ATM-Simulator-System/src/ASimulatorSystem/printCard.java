package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.awt.print.*;

public class printCard extends JFrame implements ActionListener {

    JLabel l1, bc1, ig, s, e, sg, eg, l2;
    JButton b1, b3;
    String r, cn;

    printCard(String cn) {
        this.cn = cn;
        setTitle(" Debit Card ");

        l1 = new JLabel("Here is your Card:");
        l1.setFont(new Font("Osward", Font.BOLD, 22));
        l1.setForeground(Color.BLACK);
        l1.setBounds(10, 0, 280, 28);
        add(l1);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/formcard1.png"));
        Image i2 = i1.getImage().getScaledInstance(450, 500, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        l2 = new JLabel(i3);
        l2.setBounds(20, 40, 450, 500);
        add(l2);

        bc1 = new JLabel("LOCAL BANK OF INDIA");
        bc1.setFont(new Font("Times New Roman", Font.BOLD, 28));
        bc1.setForeground(Color.orange);
        bc1.setBounds(58, 40, 400, 30);
        l2.add(bc1);

        s = new JLabel("Valid From:");
        s.setFont(new Font("Osward", Font.BOLD, 18));
        s.setForeground(Color.pink);
        s.setBounds(70, 150, 700, 30);
        l2.add(s);

        e = new JLabel("Valid UpTo:");
        e.setFont(new Font("Osward", Font.BOLD, 18));
        e.setForeground(Color.pink);
        e.setBounds(70, 180, 700, 30);
        l2.add(e);

        sg = new JLabel();
        sg.setFont(new Font("Osward", Font.BOLD, 18));
        sg.setForeground(Color.pink);
        sg.setBounds(190, 150, 700, 30);
        l2.add(sg);

        eg = new JLabel();
        eg.setFont(new Font("Osward", Font.BOLD, 18));
        eg.setForeground(Color.pink);
        eg.setBounds(190, 180, 700, 30);
        l2.add(eg);

        ig = new JLabel();
        ig.setFont(new Font("system", Font.BOLD, 28));
        ig.setForeground(Color.white);
        ig.setBounds(70, 100, 400, 30);
        l2.add(ig);

        b1 = new JButton("Print");
        b1.setBackground(Color.green);
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("Arial", Font.BOLD, 14));
        b1.setBounds(350, 540, 100, 30);
        b1.addActionListener(this);
        add(b1);

        b3 = new JButton("BACK");
        b3.setBackground(Color.red);
        b3.setForeground(Color.WHITE);
        b3.setFont(new Font("Arial", Font.BOLD, 14));
        b3.setBounds(10, 540, 80, 30);
        b3.addActionListener(this);
        add(b3);

        setLayout(null);
        r = cn;

        String query = "select * from login where cardnumber = '" + r + "'";
        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery(query);
            if (rs.next()) {
                ig.setText(rs.getString("cardnumber"));
                sg.setText(rs.getString("start"));
                eg.setText(rs.getString("end"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        getContentPane().setBackground(Color.WHITE);
        setSize(500, 630);
        setLocation(300, 40);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b3) {
            setVisible(false);
            new Bankhome("").setVisible(true);
        } else if (ae.getSource() == b1) {
            PrinterJob job = PrinterJob.getPrinterJob();
            job.setJobName("Print ATM Card");

            job.setPrintable(new Printable() {
                public int print(Graphics g, PageFormat pf, int pageIndex) throws PrinterException {
                    if (pageIndex > 0) {
                        return Printable.NO_SUCH_PAGE;
                    }

                    Graphics2D g2 = (Graphics2D) g;
                    g2.translate(pf.getImageableX(), pf.getImageableY());

                    
                    double scaleX = pf.getImageableWidth() / l2.getWidth();
                    double scaleY = pf.getImageableHeight() / l2.getHeight();
                    double scale = Math.min(scaleX, scaleY);
                    g2.scale(scale, scale);

                    l2.printAll(g2);
                    return Printable.PAGE_EXISTS;
                }
            });

            boolean ok = job.printDialog();
            if (ok) {
                try {
                    job.print();
                } catch (PrinterException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(this, "Print Failed: " + ex.getMessage());
                }
            }
        }
    }

    public static void main(String[] args) {
        new printCard("").setVisible(true);
    }
}
