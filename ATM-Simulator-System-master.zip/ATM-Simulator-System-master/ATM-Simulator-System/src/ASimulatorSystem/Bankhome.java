package ASimulatorSystem;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Bankhome extends JFrame implements ActionListener {

    JLabel l1, l3;
    JButton b1, b2, b3, b4, bd, bv, b7, b8, b9, b10;
    String pin;

    Bankhome(String pin) {
        this.pin = pin;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/bankbg.jpg"));
        Image i2 = i1.getImage().getScaledInstance(850, 450, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l2 = new JLabel(i3);
        l2.setBounds(0, 0, 850, 450);
        add(l2);

        l1 = new JLabel("Please Select Your Service : ");
        l1.setForeground(Color.GREEN);
        l1.setFont(new Font("System", Font.BOLD, 26));

        l3 = new JLabel("  WELCOME TO THE LOCAL BANK  ");
        l3.setFont(new Font("Osward", Font.BOLD, 38));
        l3.setForeground(Color.MAGENTA);
        l3.setBounds(120, 15, 700, 38);
        l2.add(l3);

        b1 = new JButton("Open New Account");
        b2 = new JButton("Create AT M");
        b3 = new JButton("Generate PassBook");
        b4 = new JButton("Generate CARD");
        bv = new JButton("View Accounts");
        b7 = new JButton("EXIT");
        b8 = new JButton("Log Out");
        b9 = new JButton("Back To AT M ");
        bd = new JButton("Delete Account");
        b10 = new JButton("Renew Card");

        setLayout(null);

        l1.setBounds(50, 100, 700, 35);
        l2.add(l1);

        b1.setBackground(Color.CYAN);
        b1.setBounds(170, 170, 150, 35);
        l2.add(b1);

        b2.setBackground(Color.CYAN);
        b2.setBounds(170, 220, 150, 35);
        l2.add(b2);

        b3.setBackground(Color.CYAN);
        b3.setBounds(170, 270, 150, 35);
        l2.add(b3);

        b4.setBackground(Color.CYAN);
        b4.setBounds(170, 320, 150, 35);
        l2.add(b4);

        b7.setBackground(Color.RED);
        b7.setBounds(50, 410, 100, 35);
        l2.add(b7);

        bv.setBackground(Color.CYAN);
        bv.setBounds(370, 170, 150, 35);
        l2.add(bv);

        bd.setBackground(Color.CYAN);
        bd.setBounds(370, 220, 150, 35);
        l2.add(bd);

        b8.setBackground(Color.GREEN);
        b8.setBounds(375, 410, 100, 35);
        l2.add(b8);

        b9.setBackground(Color.ORANGE);
        b9.setBounds(675, 410, 140, 35);
        l2.add(b9);

        b10.setBackground(Color.CYAN);
        b10.setBounds(370, 270, 150, 35);
        l2.add(b10);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b7.addActionListener(this);
        b8.addActionListener(this);
        b9.addActionListener(this);
        bv.addActionListener(this);
        bd.addActionListener(this);
        b10.addActionListener(this);

        JLabel aboutLabel = new JLabel("( i )");
        aboutLabel.setFont(new Font("Arial", Font.BOLD, 34));
        aboutLabel.setForeground(Color.RED);
        aboutLabel.setBounds(50, 20, 134, 34);
        aboutLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        aboutLabel.setToolTipText("About this Bank Management System");
        l2.add(aboutLabel);

        aboutLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JOptionPane.showMessageDialog(null,
                        "Bank Management System v1.0\n"
                        + "Developed by: Vinay Upadhyay\n"
                        + "Features:\n"
                        + "- Open New Account\n"
                        + "- ATM & Card Management\n"
                        + "- Passbook Generator\n"
                        + "- Secure Login/Logout\n"
                        + "- Transaction Management\n"
                        + "- Admin Functionalities",
                        "About", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        setSize(850, 450);
        setLocation(240, 120);
        setUndecorated(true);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            setVisible(false);
            new Signup().setVisible(true);
        } else if (ae.getSource() == b2) {
            setVisible(false);
            new createATM().setVisible(true);
        } else if (ae.getSource() == b3) {
            setVisible(false);
            new generateP().setVisible(true);
        } else if (ae.getSource() == b4) {
            new generateC().setVisible(true);
        } else if (ae.getSource() == b7) {
            System.exit(0);
        } else if (ae.getSource() == b8) {
            this.setVisible(false);
            new adlogin().setVisible(true);
        } else if (ae.getSource() == b9) {
            this.setVisible(false);
            new Login().setVisible(true);
        } else if (ae.getSource() == bv) {
            this.setVisible(false);
            new viewAccount().setVisible(true);
        } else if (ae.getSource() == bd) {
            this.setVisible(false);
            new deleteAccount().setVisible(true);
        } else if (ae.getSource() == b10) {
            this.setVisible(false);
            new reNewCard().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new Bankhome("").setVisible(true);
    }
}
