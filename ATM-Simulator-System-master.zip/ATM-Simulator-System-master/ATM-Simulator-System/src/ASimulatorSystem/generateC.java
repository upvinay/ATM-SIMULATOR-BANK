package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class generateC extends JFrame implements ActionListener {

    TextField tf;
    String acno,p;
    JLabel l1;
    JButton b1, b2;

    generateC() {
        setTitle(" Generate ");
        l1 = new JLabel("Enter The Card Number");
        l1.setFont(new Font("Times New Roman", Font.BOLD, 28));
        l1.setForeground(Color.BLUE);
        l1.setBounds(20, 44, 700, 30);
        add(l1);
        
        tf = new TextField();
        tf.setFont(new Font("System", Font.BOLD, 22));
        tf.setBounds(50, 100, 300, 30);
        add(tf);

        b1 = new JButton("Generate");
        b1.setBackground(Color.green);
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("Arial", Font.BOLD, 14));
        b1.setBounds(150, 150, 100, 30);
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("BACK");
        b2.setBackground(Color.red);
        b2.setForeground(Color.WHITE);
        b2.setFont(new Font("Arial", Font.BOLD, 14));
        b2.setBounds(150, 190, 100, 30);
        b2.addActionListener(this);
        add(b2);
        
        
        setLayout(null);

        getContentPane().setBackground(Color.pink);
        setSize(400, 300);
        setLocation(440, 180);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            p = tf.getText();
            if (p.equals("")) {
                JOptionPane.showMessageDialog(null, "Enter the vallid Acccount number");
            } else {
                String query = "select * from login where cardnumber = '" + p + "'";
                try {
                    Conn c = new Conn();
                    ResultSet rs = c.s.executeQuery(query);
                    if (rs.next()) {
                        setVisible(false);
                        new printCard(p).setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(null, "Enter the vallid Acccount number");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (ae.getSource() == b2) {
            setVisible(false);
            new Bankhome("").setVisible(true);
        }
    }

    public static void main(String args[]) {
        new generateC().setVisible(true);
    }
}
