package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.sql.*;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicScrollBarUI;

public class viewAccount extends JFrame implements ActionListener {

    JLabel heading;
    JTable table;
    JButton back;
    String balance;

    public viewAccount() {
        setTitle("Account Details");
        setUndecorated(true);
        setSize(920, 500);
        setLocationRelativeTo(null);
        setLayout(null);

        JPanel contentPane = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(25, 25, 112);
                Color color2 = new Color(0, 206, 209);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

       
        heading = new JLabel("ACCOUNT DETAILS", JLabel.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 30));
        heading.setForeground(Color.WHITE);
        heading.setBounds(0, 20, getWidth(), 40);
        contentPane.add(heading);

       
        DefaultTableModel model = new DefaultTableModel() {
            public boolean isCellEditable(int row, int column) {
                return column == 6; 
            }
        };

        String[] columns = {"Form No", "Account Number", "IFSC", "Name", "Aadhar No.", "Pan No.", "View Balance"};
        for (String col : columns) {
            model.addColumn(col);
        }

        try {
            Conn c = new Conn();
            ResultSet rs = c.s.executeQuery("SELECT a.formno, a.acno, a.ifsc, a.name, s.aadhar, s.pan FROM accountdetails a INNER JOIN signuptwo s ON a.formno = s.formno");
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("formno"),
                    rs.getString("acno"),
                    rs.getString("ifsc"),
                    rs.getString("name"),
                    rs.getString("aadhar"),
                    rs.getString("pan"),
                    "View Balance"
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database Error", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        
        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
        table.getTableHeader().setBackground(new Color(0, 102, 204));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setForeground(Color.DARK_GRAY);
        table.setSelectionBackground(new Color(173, 216, 230));
        table.setGridColor(Color.LIGHT_GRAY);

        
        table.getColumn("View Balance").setCellRenderer(new ButtonRenderer());
        table.getColumn("View Balance").setCellEditor(new ButtonEditor(new JCheckBox()));

        
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(40, 80, 840, 375);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.WHITE, 1));
        scrollPane.getVerticalScrollBar().setUI(new BasicScrollBarUI() {
            protected void configureScrollBarColors() {
                this.thumbColor = new Color(100, 149, 237);
            }
        });
        contentPane.add(scrollPane);

        
        back = new JButton(" Back");
        back.setBounds(740, 460, 130, 35);
        back.setFont(new Font("Segoe UI", Font.BOLD, 16));
        back.setBackground(Color.ORANGE);
        back.setForeground(Color.BLACK);
        back.setFocusPainted(false);
        back.setCursor(new Cursor(Cursor.HAND_CURSOR));
        back.addActionListener(this);
        contentPane.add(back);

        fadeInFrame();
        setVisible(true);
    }

    
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == back) {
            dispose();
            new viewAccount().setVisible(false);
            
            new Bankhome("").setVisible(true);
        }
    }

    
    class RoundedBorder implements Border {

        private int radius;

        RoundedBorder(int radius) {
            this.radius = radius;
        }

        public Insets getBorderInsets(Component c) {
            return new Insets(radius + 1, radius + 1, radius + 2, radius);
        }

        public boolean isBorderOpaque() {
            return true;
        }

        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
        }
    }

    
    private void fadeInFrame() {
        for (float i = 0.0f; i <= 1.0f; i += 0.05f) {
            try {
                Thread.sleep(20);
                setOpacity(i);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    
    class ButtonRenderer extends JButton implements TableCellRenderer {

        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus,
                int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

  
    class ButtonEditor extends DefaultCellEditor {

        private JButton button;
        private String acno;
        private boolean clicked;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(e -> fireEditingStopped());
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                boolean isSelected, int row, int column) {
            acno = table.getValueAt(row, 1).toString(); 
            button.setText((value == null) ? "" : value.toString());
            clicked = true;
            return button;
        }

        public Object getCellEditorValue() {
            if (clicked) {
                showBalance(acno);
            }
            clicked = false;
            return "View Balance";
        }

        public boolean stopCellEditing() {
            clicked = false;
            return super.stopCellEditing();
        }

        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }

        private void showBalance(String acno) {
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery("SELECT * FROM bank WHERE acno = '" + acno + "'");
                int balance = 0;
                boolean found = false;

                while (rs.next()) {
                    found = true;
                    String type = rs.getString("type");
                    int amount = Integer.parseInt(rs.getString("amount"));
                    if ("Deposit".equalsIgnoreCase(type)) {
                        balance += amount;
                    } else {
                        balance -= amount;
                    }
                }

                if (found) {
                    JOptionPane.showMessageDialog(null, "Account No: " + acno + "\nBalance: ₹" + balance, "Balance Info", JOptionPane.INFORMATION_MESSAGE);
                    new viewAccount().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Account No: " + acno + "\nBalance: ₹" + balance, "Balance Info", JOptionPane.INFORMATION_MESSAGE);
                    new viewAccount().setVisible(true);
                }

            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database error occurred!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(viewAccount::new);
    }
}
