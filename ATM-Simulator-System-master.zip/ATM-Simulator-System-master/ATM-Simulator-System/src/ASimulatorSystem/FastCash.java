package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.Date;

public class FastCash extends JFrame implements ActionListener {

    JLabel l1, l2;
    JButton b1, b2, b3, b4, b5, b6, b7, b8;
    JTextField t1;
    String pin,acno;

    FastCash(String pin,String acno) {
        this.pin = pin;
        this.acno=acno;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0, 0, 750, 580);
        add(l3);

        l1 = new JLabel("SELECT WITHDRAWAL AMOUNT");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));

        b1 = new JButton("Rs 100");
        b2 = new JButton("Rs 500");
        b3 = new JButton("Rs 1000");
        b4 = new JButton("Rs 2000");
        b5 = new JButton("Rs 5000");
        b6 = new JButton("Rs 10000");
        b7 = new JButton("BACK");

        setLayout(null);

        l1.setBounds(80, 120, 500, 35);
        l3.add(l1);

        b1.setBounds(70, 190, 150, 35);
        l3.add(b1);

        b2.setBounds(280, 190, 150, 35);
        l3.add(b2);

        b3.setBounds(70, 250, 150, 35);
        l3.add(b3);

        b4.setBounds(280, 250, 150, 35);
        l3.add(b4);

        b5.setBounds(70, 310, 150, 35);
        l3.add(b5);

        b6.setBounds(280, 310, 150, 35);
        l3.add(b6);

        b7.setBounds(160, 370, 150, 35);
        l3.add(b7);

        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
        b5.addActionListener(this);
        b6.addActionListener(this);
        b7.addActionListener(this);

        setSize(750,580);
        setLocation(240,60);
        setUndecorated(true);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b7) {
            this.setVisible(false);
            new Transactions(pin,acno).setVisible(true);
        }else{
            String amount = ((JButton)ae.getSource()).getText().substring(3); 
            Conn c = new Conn();
            try{
                ResultSet rs = c.s.executeQuery("select * from bank where pin = '"+pin+"' and acno = '"+acno+"'");
                int balance = 0;
                while (rs.next()) {
                    if (rs.getString("type").equals("Deposit")) {
                        balance += Integer.parseInt(rs.getString("amount"));
                    }else {
                        balance -= Integer.parseInt(rs.getString("amount"));
                    }
                } 
                if (ae.getSource() != b7 && balance < Integer.parseInt(amount)) {
                JOptionPane.showMessageDialog(null, "Insuffient Balance");
                return;
                }
                Date date = new Date();
                c.s.executeUpdate("insert into bank values('"+acno+"','"+pin+"', '"+date+"', 'Withdraw', '"+amount+"')");
                JOptionPane.showMessageDialog(null, "Rs. "+amount+" Debited Successfully");
                    
                setVisible(false);
                new Transactions(pin,acno).setVisible(true);
            }catch (Exception e) {
                System.out.println(e);
            }   
        }
    }


    public static void main(String[] args) {
        new FastCash("","").setVisible(true);
    }
}
