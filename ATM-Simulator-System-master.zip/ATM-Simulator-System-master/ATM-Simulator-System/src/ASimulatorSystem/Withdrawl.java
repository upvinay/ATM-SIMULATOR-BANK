
package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Date;
import java.sql.*;

public class Withdrawl extends JFrame implements ActionListener{
    
    JTextField t1,t2;
    JButton b1,b2,b3;
    JLabel l1,l2,l3,l4;
    String pin,acno;
    Withdrawl(String pin, String acno){
        this.pin = pin;
        this.acno=acno;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0, 0, 750, 580);
        add(l3);
        
        l1 = new JLabel("MAXIMUM WITHDRAWAL IS RS.20,000");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));
        
        l2 = new JLabel("PLEASE ENTER YOUR AMOUNT");
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("System", Font.BOLD, 16));
        
        t1 = new JTextField();
        t1.setFont(new Font("Raleway", Font.BOLD, 25));
        
        b1 = new JButton("WITHDRAW");
        b2 = new JButton("BACK");
        
        setLayout(null);
        
        l1.setBounds(50,90,400,20);
        l3.add(l1);
        
        l2.setBounds(80,210,400,20);
        l3.add(l2);
        
        t1.setBounds(80,250,340,30);
        l3.add(t1);
        
        b1.setBounds(180,310,150,35);
        l3.add(b1);
        
        b2.setBounds(180,370,150,35);
        l3.add(b2);
        
        b1.addActionListener(this);
        b2.addActionListener(this);
        
        setSize(750,580);
        setLocation(240,60);
        setUndecorated(true);
        setVisible(true);
    }
    
    
    public void actionPerformed(ActionEvent ae){
        String amount = t1.getText();
        Date date = new Date();
        if(ae.getSource()==b1){
            if(amount.equals("")){
            JOptionPane.showMessageDialog(null, "Please enter the Amount to you want to Withdraw");
            }else if(Integer.valueOf(amount)>20000){
            JOptionPane.showMessageDialog(null, "Please Enter a Vallid Amount ( less or equals to 20000 ) ");
            }else if(Integer.valueOf(amount)%100!=0){
            JOptionPane.showMessageDialog(null, "Please Enter a Vallid Amount ( Multiple number of cash 100Rs & 200Rs & 500Rs .)");
            }else{
                try{   
                    Conn c1 = new Conn();
                    c1.s.executeUpdate("insert into bank values('"+acno+"','"+pin+"', '"+date+"', 'Withdraw', '"+amount+"')");
                    JOptionPane.showMessageDialog(null, "Rs. "+amount+" Withdrawal Successfully");
                    setVisible(false);
                    new Transactions(pin,acno).setVisible(true);
                }catch(Exception e){
                    System.out.println(e);
                    }
                }
            }
        else if(ae.getSource()==b2){
            setVisible(false);
            new Transactions(pin,acno).setVisible(true);
        }
    }
    
    
    public static void main(String[] args){
        new Withdrawl("","").setVisible(true);
    }
}






