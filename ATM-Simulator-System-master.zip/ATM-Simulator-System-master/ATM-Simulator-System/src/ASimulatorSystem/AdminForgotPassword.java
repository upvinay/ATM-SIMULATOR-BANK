package ASimulatorSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class AdminForgotPassword extends JFrame implements ActionListener {

    JLabel title, instruction, userLabel, dobLabel, formatLabel;
    JTextField userField, dobField;
    JButton nextButton, backButton;
    JPanel formPanel;

    AdminForgotPassword() {
        setTitle("Forget Admin Password");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

       
        getContentPane().setBackground(new Color(220, 235, 245)); 

        
        title = new JLabel("FORGOT ADMIN PASSWORD");
        title.setFont(new Font("Segoe UI Black", Font.BOLD, 30));
        title.setForeground(Color.RED);
        title.setBounds(150, 20, 600, 40);
        add(title);

       
        instruction = new JLabel("Enter the Date of Birth for Verification");
        instruction.setFont(new Font("Segoe UI", Font.BOLD, 16));
        instruction.setForeground(new Color(30, 136, 229));
        instruction.setBounds(220, 65, 400, 25);
        add(instruction);

        
        formPanel = new JPanel();
        formPanel.setLayout(null);
        formPanel.setBounds(100, 100, 600, 180);
        formPanel.setBackground(new Color(255, 255, 255, 230)); 
        formPanel.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0, 40), 1));
        add(formPanel);

       
        userLabel = new JLabel("User ID:");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        userLabel.setBounds(40, 20, 100, 30);
        formPanel.add(userLabel);

        userField = new JTextField();
        userField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        userField.setBounds(150, 20, 380, 30);
        formPanel.add(userField);

       
        dobLabel = new JLabel("Date of Birth:");
        dobLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        dobLabel.setBounds(40, 70, 120, 30);
        formPanel.add(dobLabel);

        dobField = new JTextField();
        dobField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        dobField.setBounds(150, 70, 380, 30);
        formPanel.add(dobField);

        formatLabel = new JLabel("(DD/MM/YYYY)");
        formatLabel.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        formatLabel.setForeground(Color.DARK_GRAY);
        formatLabel.setBounds(150, 100, 120, 20);
        formPanel.add(formatLabel);

       
        nextButton = new JButton("Next");
        nextButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        nextButton.setBackground(new Color(76, 175, 80));
        nextButton.setForeground(Color.WHITE);
        nextButton.setBounds(150, 130, 120, 30);
        nextButton.addActionListener(this);
        formPanel.add(nextButton);

        backButton = new JButton("Back");
        backButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        backButton.setBackground(new Color(255, 82, 82));
        backButton.setForeground(Color.WHITE);
        backButton.setBounds(310, 130, 120, 30);
        backButton.addActionListener(this);
        formPanel.add(backButton);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == nextButton) {
            String userid = userField.getText();
            String dob = dobField.getText();
            String query = "SELECT * FROM admin WHERE adminid = '" + userid + "' AND dob = '" + dob + "'";
            try {
                Conn c = new Conn();
                ResultSet rs = c.s.executeQuery(query);
                if (rs.next()) {
                    JOptionPane.showMessageDialog(null, "Admin verified successfully.");
                    setVisible(false);
                    new AdPinChange().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid credentials. Try again.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == backButton) {
            setVisible(false);
            new adlogin().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new AdminForgotPassword().setVisible(true);
    }
}
