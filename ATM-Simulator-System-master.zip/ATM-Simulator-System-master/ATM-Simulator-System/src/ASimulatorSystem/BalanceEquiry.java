package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import javax.swing.*;
import java.util.*;

class BalanceEnquiry extends JFrame implements ActionListener {

    JTextField t1, t2;
    JButton b1, b2, b3;
    JLabel l1, l2, l3,l5,l6;
    String pin,acno;

    BalanceEnquiry(String pin,String acno) {
        this.pin = pin;
        this.acno=acno;

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1000, 1180, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0, 0, 750, 580);
        add(l3);

        l1 = new JLabel();
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("System", Font.BOLD, 16));
        
        l5 = new JLabel("Your Account Balance Shown   : :   Bellow !");
        l5.setForeground(Color.WHITE);
        l5.setFont(new Font("System", Font.BOLD, 16));
        l3.add(l5);
        l5.setBounds(80,100,500,35);
        
        l6 = new JLabel("A/c No  : "+acno);
        l6.setForeground(Color.WHITE);
        l6.setFont(new Font("System", Font.BOLD, 16));
        l3.add(l6);
        l6.setBounds(80,140,500,35);
        
        b1 = new JButton("BACK");

        setLayout(null);

        l1.setBounds(80, 220, 400, 35);
        l3.add(l1);

        b1.setBounds(190, 370, 150, 35);
        l3.add(b1);
        int balance = 0 ;
        try{
            Conn c1 = new Conn();
            ResultSet rs = c1.s.executeQuery("select * from bank where acno = '"+acno+"'");
            while (rs.next()) {
                if (rs.getString("type").equals("Deposit")) {
                    balance += Integer.parseInt(rs.getString("amount"));
                } else {
                    balance -= Integer.parseInt(rs.getString("amount"));
                }
            }
        }catch(Exception e){}
        
        l1.setText("Balance : "+balance);

        b1.addActionListener(this);

        setSize(750,580);
        setLocation(240,60);
        setUndecorated(true);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Transactions(pin,acno).setVisible(true);
    }

    public static void main(String[] args) {
        new BalanceEnquiry("","").setVisible(true);
    }
}
