package ASimulatorSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdPinChange extends JFrame implements ActionListener {

    private JPasswordField t1, t2;
    private JButton b1, b2;

    public AdPinChange() {
        setTitle("Admin - Change PIN");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setUndecorated(true);
        setLayout(null);
        
        JPanel bgPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(0, 92, 151), 0, getHeight(), new Color(144, 224, 239));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        bgPanel.setBounds(0, 0, 600, 500);
        bgPanel.setLayout(null);
        add(bgPanel);

        JLabel quote = new JLabel("“Securing the Future of Banking”");
        quote.setFont(new Font("Segoe UI", Font.BOLD, 22));
        quote.setForeground(Color.WHITE);
        quote.setOpaque(true);  
        quote.setBackground(new Color(255, 105, 180)); 
        quote.setHorizontalAlignment(SwingConstants.CENTER);
        quote.setBounds(100, 30, 400, 35);
        bgPanel.add(quote);

        Timer glowTimer = new Timer(200, new ActionListener() {
            private int alpha = 0;
            private boolean fadingIn = true;

            public void actionPerformed(ActionEvent e) {
                if (fadingIn) {
                    alpha += 10;
                    if (alpha >= 255) {
                        fadingIn = false;
                    }
                } else {
                    alpha -= 10;
                    if (alpha <= 50) {
                        fadingIn = true;
                    }
                }
                quote.setForeground(new Color(255, 255, 255, Math.min(alpha, 255)));
            }
        });
        glowTimer.start();

         
        JPanel glassPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(255, 255, 255, 60));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                super.paintComponent(g);
            }
        };
        glassPanel.setOpaque(false);
        glassPanel.setLayout(null);
        glassPanel.setBounds(100, 100, 400, 300);
        glassPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 120), 2));
        bgPanel.add(glassPanel);

        JLabel heading = new JLabel("Change Admin PIN");
        heading.setFont(new Font("Segoe UI Black", Font.BOLD, 22));
        heading.setForeground(new Color(0, 51, 102));
        heading.setBounds(90, 20, 250, 30);
        glassPanel.add(heading);

        JLabel lblNew = new JLabel("New PIN:");
        lblNew.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblNew.setBounds(40, 70, 100, 25);
        glassPanel.add(lblNew);

        t1 = new JPasswordField();
        t1.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        t1.setBounds(150, 70, 200, 30);
        t1.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        glassPanel.add(t1);

        JLabel lblRe = new JLabel("Confirm PIN:");
        lblRe.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblRe.setBounds(40, 120, 120, 25);
        glassPanel.add(lblRe);

        t2 = new JPasswordField();
        t2.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        t2.setBounds(150, 120, 200, 30);
        t2.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        glassPanel.add(t2);

        b1 = new JButton("Update PIN");
        styleButton(b1, new Color(34, 139, 34));
        b1.setBounds(40, 190, 150, 40);
        glassPanel.add(b1);

        b2 = new JButton("Cancel");
        styleButton(b2, new Color(220, 20, 60));
        b2.setBounds(200, 190, 150, 40);
        glassPanel.add(b2);

        b1.addActionListener(this);
        b2.addActionListener(this);

        setVisible(true);
    }

    private void styleButton(JButton button, Color color) {
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 100), 2));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
    }

    public void actionPerformed(ActionEvent ae) {
        String npin = new String(t1.getPassword());
        String rpin = new String(t2.getPassword());

        if (ae.getSource() == b1) {
            if (!npin.equals(rpin)) {
                JOptionPane.showMessageDialog(this, "PINs do not match");
                return;
            }

            if (npin.equals("") || rpin.equals("")) {
                JOptionPane.showMessageDialog(this, "Please enter both PIN fields");
                return;
            }

            try {
                Conn c1 = new Conn();
                String query = "UPDATE admin SET pass = '" + rpin + "'";
                int result = c1.s.executeUpdate(query);

                if (result > 0) {
                    JOptionPane.showMessageDialog(this, "PIN updated successfully");
                    setVisible(false);
                    new adlogin().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Update failed");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        } else if (ae.getSource() == b2) {
            setVisible(false);
            new adlogin().setVisible(true);
        }
    }

    public static void main(String[] args) {
        new AdPinChange();
    }
}
