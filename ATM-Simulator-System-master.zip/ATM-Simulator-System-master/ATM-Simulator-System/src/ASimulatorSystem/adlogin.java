package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.awt.geom.RoundRectangle2D;

public class adlogin extends JFrame implements ActionListener {

    private JTextField tf1;
    private JPasswordField pf2;
    private JButton b1, b2, b3, b4;

    public adlogin() {
        setTitle("Bank : Admin Login");
        setSize(850, 600);
        setLocationRelativeTo(null);
        setUndecorated(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        GradientPanel background = new GradientPanel();
        setContentPane(background);
        background.setLayout(null);

        initUI(background);
        startQuoteAnimation(background);
        setVisible(true);
    }

    private void initUI(JPanel panel) {
       
        JPanel glassPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(255, 255, 255, 70));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                super.paintComponent(g);
            }
        };
        glassPanel.setOpaque(false);
        glassPanel.setLayout(null);
        glassPanel.setBounds(200, 100, 450, 400);
        glassPanel.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 120), 2));
        panel.add(glassPanel);

        JLabel logo = new JLabel(new ImageIcon(new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/second.jpg")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH)));
        logo.setBounds(190, 10, 80, 80);
        glassPanel.add(logo);

        JLabel title = new JLabel("Admin Login");
        title.setFont(new Font("Segoe UI Black", Font.BOLD, 28));
        title.setForeground(Color.WHITE);
        title.setBounds(130, 100, 250, 40);
        glassPanel.add(title);

        JLabel l2 = new JLabel("User ID:");
        l2.setFont(new Font("Segoe UI", Font.BOLD, 16));
        l2.setForeground(Color.WHITE);
        l2.setBounds(60, 150, 100, 25);
        glassPanel.add(l2);

        tf1 = new JTextField();
        tf1.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tf1.setBounds(160, 150, 220, 30);
        tf1.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        glassPanel.add(tf1);

        JLabel l3 = new JLabel("PIN:");
        l3.setFont(new Font("Segoe UI", Font.BOLD, 16));
        l3.setForeground(Color.WHITE);
        l3.setBounds(60, 200, 100, 25);
        glassPanel.add(l3);

        pf2 = new JPasswordField();
        pf2.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        pf2.setBounds(160, 200, 220, 30);
        pf2.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        glassPanel.add(pf2);

        b1 = createButton("SIGN IN", new Color(0, 153, 51));
        b1.setBounds(60, 260, 140, 40);
        glassPanel.add(b1);

        b2 = createButton("CLEAR", new Color(204, 0, 0));
        b2.setBounds(240, 260, 140, 40);
        glassPanel.add(b2);

        b3 = createButton("BACK TO ATM", new Color(0, 102, 204));
        b3.setBounds(60, 320, 320, 35);
        glassPanel.add(b3);

        b4 = createButton("Forgot Admin/Password", new Color(255, 140, 0));
        b4.setBounds(60, 365, 320, 30);
        glassPanel.add(b4);

      
        b1.addActionListener(this);
        b2.addActionListener(this);
        b3.addActionListener(this);
        b4.addActionListener(this);
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI Semibold", Font.BOLD, 15));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 100), 1));
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        return button;
    }

    private void startQuoteAnimation(JPanel panel) {
        String[] quotes = {
            "\"Banking made easy, just for you.\"",
            "\"Your trust, our commitment.\"",
            "\"Secure. Reliable. Seamless.\"",
            "\"Experience the future of banking today.\""
        };

     
        JPanel quoteBackground = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(255, 140, 0, 200), getWidth(), getHeight(), new Color(255, 20, 147, 200));
                g2.setPaint(gp);
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
            }
        };
        quoteBackground.setBounds(180, 30, 540, 50);
        quoteBackground.setOpaque(false);
        quoteBackground.setLayout(new BorderLayout());
        panel.add(quoteBackground);

        JLabel quoteLabel = new JLabel(quotes[0], SwingConstants.CENTER);
        quoteLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        quoteLabel.setForeground(Color.WHITE);
        quoteLabel.setHorizontalAlignment(SwingConstants.CENTER);
        quoteLabel.setVerticalAlignment(SwingConstants.CENTER);
        quoteLabel.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        quoteBackground.add(quoteLabel);

      
        Timer quoteTimer = new Timer(4000, new ActionListener() {
            int i = 1;

            @Override
            public void actionPerformed(ActionEvent e) {
                quoteLabel.setText(quotes[i % quotes.length]);
                quoteLabel.setForeground(new Color(255, 255, 255, 0));

              
                new Timer(20, new ActionListener() {
                    int alpha = 0;

                    public void actionPerformed(ActionEvent ev) {
                        alpha += 15;
                        if (alpha >= 255) {
                            alpha = 255;
                            ((Timer) ev.getSource()).stop();
                        }
                        quoteLabel.setForeground(new Color(255, 255, 255, alpha));
                    }
                }).start();

                i++;
            }
        });
        quoteTimer.setInitialDelay(1000);
        quoteTimer.start();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        try {
            if (ae.getSource() == b1) {
                Conn c = new Conn();
                String adminid = tf1.getText();
                String pass = new String(pf2.getPassword());
                String q = "SELECT * FROM admin WHERE adminid = '" + adminid + "' AND pass = '" + pass + "'";
                ResultSet rs = c.s.executeQuery(q);
                if (rs.next()) {
                    setVisible(false);
                    new loading().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, " User_id or Password is Incorrect ");
                }
            } else if (ae.getSource() == b2) {
                tf1.setText("");
                pf2.setText("");
            } else if (ae.getSource() == b3) {
                setVisible(false);
                new Login().setVisible(true);
            } else if (ae.getSource() == b4) {
                setVisible(false);
                new AdminForgotPassword().setVisible(true);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(adlogin::new);

    }

    
    class GradientPanel extends JPanel {

        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            GradientPaint gp = new GradientPaint(0, 0, new Color(10, 24, 61), 0, getHeight(), new Color(0, 212, 255));
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}
