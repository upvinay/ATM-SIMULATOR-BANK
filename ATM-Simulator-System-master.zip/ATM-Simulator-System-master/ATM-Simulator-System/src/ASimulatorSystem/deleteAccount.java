package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class deleteAccount extends JFrame implements ActionListener {

    TextField tf1;
    JButton search, back, del;
    JLabel l3, namel, n, d, a, i, ac, p, ng, dg, ag, ig, acg, pg;
    int fng;
    String r;

    deleteAccount() {

        getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null);
        l3 = new JLabel("  Remove Account ");
        l3.setFont(new Font("Osward", Font.BOLD, 26));
        l3.setForeground(Color.RED);
        l3.setBounds(320, 5, 600, 38);
        add(l3);

        JLabel searchlbl = new JLabel("Search by Bank Account Number");
        searchlbl.setFont(new Font("System", Font.BOLD, 22));
        searchlbl.setForeground(Color.orange);
        searchlbl.setBounds(20, 50, 350, 30);
        add(searchlbl);

        tf1 = new TextField();
        tf1.setFont(new Font("System", Font.BOLD, 22));
        tf1.setBounds(400, 50, 470, 30);
        add(tf1);

        namel = new JLabel();
        namel.setFont(new Font("Osward", Font.BOLD, 30));
        namel.setForeground(Color.MAGENTA);
        namel.setBounds(120, 150, 700, 38);
        add(namel);

        n = new JLabel("Name : ");
        n.setFont(new Font("Osward", Font.BOLD, 22));
        n.setForeground(Color.white);
        n.setBounds(250, 150, 700, 30);
        add(n);
        ac = new JLabel("Account Number : ");
        ac.setFont(new Font("Osward", Font.BOLD, 22));
        ac.setForeground(Color.white);
        ac.setBounds(135, 190, 700, 30);
        add(ac);
        i = new JLabel("IFSC Code : ");
        i.setFont(new Font("Osward", Font.BOLD, 22));
        i.setForeground(Color.white);
        i.setBounds(200, 230, 700, 30);
        add(i);
        d = new JLabel("D.O.B. :");
        d.setFont(new Font("Osward", Font.BOLD, 22));
        d.setForeground(Color.white);
        d.setBounds(245, 270, 700, 30);
        add(d);

        a = new JLabel("Adhar Number :");
        a.setFont(new Font("Osward", Font.BOLD, 22));
        a.setForeground(Color.white);
        a.setBounds(160, 310, 700, 30);
        add(a);

        p = new JLabel("Pan Number :");
        p.setFont(new Font("Osward", Font.BOLD, 22));
        p.setForeground(Color.white);
        p.setBounds(180, 350, 700, 30);
        add(p);

        ng = new JLabel();
        ng.setFont(new Font("Osward", Font.BOLD, 22));
        ng.setForeground(Color.white);
        ng.setBounds(350, 150, 700, 30);
        add(ng);
        acg = new JLabel();
        acg.setFont(new Font("Osward", Font.BOLD, 22));
        acg.setForeground(Color.white);
        acg.setBounds(350, 190, 700, 30);
        add(acg);
        ig = new JLabel();
        ig.setFont(new Font("Osward", Font.BOLD, 22));
        ig.setForeground(Color.white);
        ig.setBounds(350, 230, 700, 30);
        add(ig);
        dg = new JLabel();
        dg.setFont(new Font("Osward", Font.BOLD, 22));
        dg.setForeground(Color.white);
        dg.setBounds(350, 270, 700, 30);
        add(dg);

        ag = new JLabel();
        ag.setFont(new Font("Osward", Font.BOLD, 22));
        ag.setForeground(Color.white);
        ag.setBounds(350, 310, 700, 30);
        add(ag);

        pg = new JLabel();
        pg.setFont(new Font("Osward", Font.BOLD, 22));
        pg.setForeground(Color.white);
        pg.setBounds(350, 350, 700, 30);
        add(pg);

        search = new JButton("Search");
        search.setBackground(Color.cyan);
        search.setFont(new Font("System", Font.BOLD, 22));
        search.setBounds(270, 100, 150, 30);
        search.addActionListener(this);
        add(search);

        back = new JButton("Back");
        back.setBackground(Color.cyan);
        back.setFont(new Font("System", Font.BOLD, 22));
        back.setBounds(500, 100, 150, 30);
        back.addActionListener(this);
        add(back);

        del = new JButton("Delete");
        del.setBackground(Color.red);
        del.setFont(new Font("System", Font.BOLD, 22));
        del.setBounds(650, 400, 150, 30);
        del.addActionListener(this);
        add(del);

        setSize(900, 480);
        setLocation(200, 50);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == search) {
            r = tf1.getText();
            if (r.equals("")) {
                JOptionPane.showMessageDialog(null, "Enter the vallid Acccount number");
            } else {
                String query = "select * from accountdetails where acno = '" + r + "'";
                try {
                    Conn c = new Conn();
                    ResultSet rs = c.s.executeQuery(query);
                    if (rs.next()) {
                        ng.setText(rs.getString("name"));
                        acg.setText(rs.getString("acno"));
                        ig.setText(rs.getString("ifsc"));
                        fng = Integer.parseInt(rs.getString("formno"));
                    } else {
                        JOptionPane.showMessageDialog(null, "Enter the vallid Account number");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                String query1 = "select * from signuptwo where formno = '" + fng + "'";
                try {
                    Conn c1 = new Conn();
                    ResultSet rs1 = c1.s.executeQuery(query1);
                    while (rs1.next()) {
                        ag.setText(rs1.getString("aadhar"));
                        pg.setText(rs1.getString("pan"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                String query2 = "select * from signup where formno = '" + fng + "'";
                try {
                    Conn c1 = new Conn();
                    ResultSet rs1 = c1.s.executeQuery(query2);
                    while (rs1.next()) {
                        dg.setText(rs1.getString("dob"));
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (ae.getSource() == del) {

            String query3 = "delete from accountdetails where acno = '" + r + "'";
            String query4 = "delete from signuptwo where formno = '" + fng + "'";
            String query5 = "delete from signup where formno = '" + fng + "'";
            String query6 = "delete from login where acno = '" + r + "'";
            try {
                Conn c = new Conn();
                int rowsAffected = c.s.executeUpdate(query3);
                int rowsAffected1 = c.s.executeUpdate(query4);
                int rowsAffected2 = c.s.executeUpdate(query5);
                int rowAffected3 = c.s.executeUpdate(query6);
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Account Deleted Successfully.");
                    ng.setText("");
                    acg.setText("");
                    ig.setText("");
                    dg.setText("");
                    ag.setText("");
                    pg.setText("");

                } else {
                    JOptionPane.showMessageDialog(null, "No account found to delete.");
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            setVisible(false);
            new Bankhome("").setVisible(true);
        }
    }

    public static void main(String[] args) {
        new deleteAccount().setVisible(true);
    }
}
