package ASimulatorSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;

public class Signup extends JFrame implements ActionListener {

    JLabel l1, l2;
    JTextField t1, t2, t3, t4, t5, t6, t7;
    JRadioButton r1, r2, r3, r4, r5;
    JButton b, b1;
    JDateChooser dateChooser;
    String name;

    Random ran = new Random();
    long first4 = (ran.nextLong() % 9000L) + 1000L;
    String first = "" + Math.abs(first4);

    Signup() {
        setTitle("Create New Account");
        setLayout(null);

        
        JPanel background = new JPanel();
        background.setLayout(null);
        background.setBackground(new Color(245, 245, 250));
        background.setBounds(0, 0, 800, 600);
        add(background);

        
        l1 = new JLabel("APPLICATION FORM NO. " + first);
        l1.setFont(new Font("Segoe UI", Font.BOLD, 24));
        l1.setBounds(180, 20, 450, 30);
        l1.setForeground(new Color(33, 64, 128));
        background.add(l1);

        
        JLabel infoIcon = new JLabel("(!)");
        infoIcon.setFont(new Font("Segoe UI", Font.BOLD, 38));
        infoIcon.setForeground(new Color(33, 64, 128));
        infoIcon.setBounds(700, 50, 70, 40);
        infoIcon.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        background.add(infoIcon);

        
        JPopupMenu rulesPopup = new JPopupMenu();
        rulesPopup.setBackground(Color.WHITE);
        rulesPopup.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        String[] rules = {
            "1. Name and Father's Name must be in UPPERCASE letters only.",
            "2. Email Address: Max 20 characters allowed.",
            "3. Address, City, State: Alphabets and spaces only.",
            "4. Pin Code: Numeric, max 6 digits.",
            "5. All fields must be filled before clicking Next."
        };

        for (String rule : rules) {
            JMenuItem item = new JMenuItem(rule);
            item.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            item.setBackground(Color.WHITE);
            item.setForeground(Color.DARK_GRAY);
            item.setEnabled(false);
            rulesPopup.add(item);
        }

        infoIcon.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                rulesPopup.show(infoIcon, infoIcon.getWidth(), infoIcon.getHeight());
            }

            @Override
            public void mouseExited(MouseEvent e) {
                rulesPopup.setVisible(false);
            }
        });

        l2 = new JLabel("Page 1: Personal Details");
        l2.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        l2.setBounds(280, 60, 300, 24);
        background.add(l2);

        Font labelFont = new Font("Segoe UI", Font.PLAIN, 14);

        String[] labels = {
            "Name:", "Father's Name:", "Date of Birth:", "Gender:",
            "Email Address:", "Marital Status:", "Address:", "City:", "Pin Code:", "State:"
        };

        int y = 100;
        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(labelFont);
            lbl.setBounds(100, y, 150, 25);
            background.add(lbl);
            y += 40;
        }

        t1 = createTextField(300, 100);
        background.add(t1);
        t1.addKeyListener(uppercaseLimitKeyListener(t1, 20));

        t2 = createTextField(300, 140);
        background.add(t2);
        t2.addKeyListener(uppercaseLimitKeyListener(t2, 20));

        dateChooser = new JDateChooser();
        dateChooser.setBounds(300, 180, 400, 30);
        dateChooser.setFont(labelFont);
        background.add(dateChooser);

        r1 = createRadio("Male", 300, 220);
        r2 = createRadio("Female", 400, 220);
        background.add(r1);
        background.add(r2);
        ButtonGroup gGender = new ButtonGroup();
        gGender.add(r1);
        gGender.add(r2);

        t3 = createTextField(300, 260);
        background.add(t3);
        t3.addKeyListener(limitLengthKeyListener(t3, 20));

        r3 = createRadio("Married", 300, 300);
        r4 = createRadio("Unmarried", 400, 300);
        r5 = createRadio("Other", 500, 300);
        background.add(r3);
        background.add(r4);
        background.add(r5);
        ButtonGroup gStatus = new ButtonGroup();
        gStatus.add(r3);
        gStatus.add(r4);
        gStatus.add(r5);

        t4 = createTextField(300, 340);
        background.add(t4);
        t4.addKeyListener(alphaSpaceLimitKeyListener(t4, 20));

        t5 = createTextField(300, 380);
        background.add(t5);
        t5.addKeyListener(alphaSpaceLimitKeyListener(t5, 20));

        t6 = createTextField(300, 420);
        background.add(t6);
        t6.addKeyListener(digitLimitKeyListener(t6, 6));

        t7 = createTextField(300, 460);
        background.add(t7);
        t7.addKeyListener(alphaSpaceLimitKeyListener(t7, 15));

        b = createButton("Next", 580, 510);
        b1 = createButton("Back", 100, 510);
        background.add(b);
        background.add(b1);

        b.addActionListener(this);
        b1.addActionListener(this);

        setSize(800, 600);
        setLocationRelativeTo(null);
        setUndecorated(false);
        setVisible(true);
    }

    private JTextField createTextField(int x, int y) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBounds(x, y, 400, 30);
        tf.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        tf.setBackground(Color.WHITE);
        return tf;
    }

    private JRadioButton createRadio(String text, int x, int y) {
        JRadioButton rb = new JRadioButton(text);
        rb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        rb.setBackground(new Color(245, 245, 250));
        rb.setBounds(x, y, 100, 25);
        return rb;
    }

    private JButton createButton(String text, int x, int y) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBounds(x, y, 120, 35);
        btn.setBackground(new Color(33, 64, 128));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createEmptyBorder());
        return btn;
    }

    private KeyAdapter uppercaseLimitKeyListener(JTextField field, int limit) {
        return new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isUpperCase(c) && !Character.isWhitespace(c)) {
                    e.consume();
                }
                if (field.getText().length() >= limit) {
                    e.consume();
                }
            }
        };
    }

    private KeyAdapter alphaSpaceLimitKeyListener(JTextField field, int limit) {
        return new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isLetter(c) && !Character.isWhitespace(c)) {
                    e.consume();
                }
                if (field.getText().length() >= limit) {
                    e.consume();
                }
            }
        };
    }

    private KeyAdapter digitLimitKeyListener(JTextField field, int limit) {
        return new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume();
                }
                if (field.getText().length() >= limit) {
                    e.consume();
                }
            }
        };
    }

    private KeyAdapter limitLengthKeyListener(JTextField field, int limit) {
        return new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                if (field.getText().length() >= limit) {
                    e.consume();
                }
            }
        };
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b) {
            String formno = first;
            name = t1.getText();
            String fname = t2.getText();

         
            Date selectedDate = dateChooser.getDate();
            String dob = "";
            if (selectedDate != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                sdf.setLenient(false);  
                dob = sdf.format(selectedDate);
            }

            String gender = r1.isSelected() ? "Male" : (r2.isSelected() ? "Female" : null);
            String email = t3.getText();
            String marital = r3.isSelected() ? "Married" : (r4.isSelected() ? "Unmarried" : (r5.isSelected() ? "Other" : null));
            String address = t4.getText();
            String city = t5.getText();
            String pincode = t6.getText();
            String state = t7.getText();

            try {
                if (name.equals("") || fname.equals("") || dob.equals("") || gender == null || email.equals("")
                        || marital == null || address.equals("") || city.equals("") || pincode.equals("") || state.equals("")) {
                    JOptionPane.showMessageDialog(null, "Fill all the required fields correctly including Date of Birth.");
                } else {
                    Conn c1 = new Conn();
                    String q1 = "insert into signup values('" + formno + "','" + name + "','" + fname + "','" + dob + "','" + gender + "','" + email + "','" + marital + "','" + address + "','" + city + "','" + pincode + "','" + state + "')";
                    c1.s.executeUpdate(q1);
                    new Signup2(formno, name).setVisible(true);
                    setVisible(false);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else if (ae.getSource() == b1) {
            setVisible(false);
            new Bankhome("").setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Signup::new);
    }
}
