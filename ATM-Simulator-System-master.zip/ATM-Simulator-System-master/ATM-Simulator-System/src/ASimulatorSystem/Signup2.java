package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.Random;

public class Signup2 extends JFrame implements ActionListener {

    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, l13;
    JButton b;
    JRadioButton r1, r2;
    JTextField t1, t2;
    JComboBox c1, c2, c3, c4, c5;
    String formno, name;

    Signup2(String formno, String name) {

       
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/logo.jpg"));
        Image i2 = i1.getImage().getScaledInstance(100, 100, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l14 = new JLabel(i3);
        l14.setBounds(60, 10, 100, 80);
        add(l14);

       
        this.formno = formno;
        this.name = name;
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 2");

        JLabel infoIcon = new JLabel("(!)");
        infoIcon.setFont(new Font("Segoe UI", Font.BOLD, 38));
        infoIcon.setForeground(new Color(33, 64, 128));
        infoIcon.setBounds(680, 50, 70, 40);
        infoIcon.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        add(infoIcon);

      
        JPopupMenu rulesPopup = new JPopupMenu();
        rulesPopup.setBackground(Color.WHITE);
        rulesPopup.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        String[] rules = {
            "1. The Pan Card Field takes only 10 AlphaNumeric.",
            "2. The Pan Card Field takes only Capital letter characters.",
            "3. Adhar Card should Numeric only.",
            "4. And also Adhar Card field takes 12 Digits.",
            "5. All fields must be filled before clicking Next."
        };

        for (String rule : rules) {
            JMenuItem item = new JMenuItem(rule);
            item.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            item.setBackground(Color.WHITE);
            item.setForeground(Color.DARK_GRAY);
            item.setEnabled(false);
            rulesPopup.add(item);
        }

        infoIcon.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                rulesPopup.show(infoIcon, infoIcon.getWidth(), infoIcon.getHeight());
            }

            @Override
            public void mouseExited(MouseEvent e) {
                rulesPopup.setVisible(false);
            }
        });

      
        l1 = new JLabel("     Page 2    :    Additional Details");
        l1.setFont(new Font("Segoe UI", Font.BOLD, 22));
        l1.setForeground(new Color(33, 64, 128));

        l2 = new JLabel("Religion:");
        l3 = new JLabel("Category:");
        l4 = new JLabel("Income:");
        l5 = new JLabel("Educational");
        l11 = new JLabel("Qualification:");
        l6 = new JLabel("Occupation:");
        l7 = new JLabel("PAN Number:");
        l8 = new JLabel("Aadhar Number:");

        l12 = new JLabel("Form No:");
        l13 = new JLabel(formno);

        b = new JButton("Next");
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setBackground(new Color(33, 64, 128));
        b.setForeground(Color.WHITE);

       
        t1 = new JTextField();  
        t1.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        t1.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {

                char c = e.getKeyChar();
                if (!(Character.isLetter(c) && Character.isUpperCase(c)) && !Character.isDigit(c)) {
                    e.consume();
                }
                if (t1.getText().length() >= 10) {
                    e.consume();
                }
            }
        });

        t2 = new JTextField(); 
        t2.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        t2.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                
                char c = e.getKeyChar();
                if (!Character.isDigit(c)) {
                    e.consume(); 
                }
                if (t2.getText().length() >= 12) {
                    e.consume();  
                }
            }
        });

      
        String religion[] = {"Hindu", "Muslim", "Sikh", "Christian", "Other"};
        c1 = new JComboBox(religion);
        c1.setBackground(Color.WHITE);
        c1.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        String category[] = {"General", "OBC", "SC", "ST", "Other"};
        c2 = new JComboBox(category);
        c2.setBackground(Color.WHITE);
        c2.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        String income[] = {"Null", "<1,50,000", "<2,50,000", "<5,00,000", "Upto 10,00,000", "Above 10,00,000"};
        c3 = new JComboBox(income);
        c3.setBackground(Color.WHITE);
        c3.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        String education[] = {"Non-Graduate", "Graduate", "Post-Graduate", "Doctrate", "Others"};
        c4 = new JComboBox(education);
        c4.setBackground(Color.WHITE);
        c4.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        String occupation[] = {"Salaried", "Self-Employed", "Business", "Student", "Retired", "Others"};
        c5 = new JComboBox(occupation);
        c5.setBackground(Color.WHITE);
        c5.setFont(new Font("Segoe UI", Font.PLAIN, 14));

       
        setLayout(null);

        l12.setBounds(580, 10, 60, 30);
        add(l12);

        l13.setBounds(650, 10, 60, 30);
        add(l13);

        l1.setBounds(150, 25, 600, 40);
        add(l1);

        l2.setBounds(100, 100, 100, 30);
        add(l2);
        c1.setBounds(350, 100, 320, 30);
        add(c1);

        l3.setBounds(100, 140, 100, 30);
        add(l3);
        c2.setBounds(350, 140, 320, 30);
        add(c2);

        l4.setBounds(100, 180, 100, 30);
        add(l4);
        c3.setBounds(350, 180, 320, 30);
        add(c3);

        l5.setBounds(100, 220, 150, 30);
        add(l5);
        c4.setBounds(350, 220, 320, 30);
        add(c4);

        l11.setBounds(100, 260, 150, 30);
        add(l11);

        l6.setBounds(100, 300, 150, 30);
        add(l6);
        c5.setBounds(350, 300, 320, 30);
        add(c5);

        l7.setBounds(100, 340, 150, 30);
        add(l7);
        t1.setBounds(350, 340, 320, 30);
        add(t1);

        l8.setBounds(100, 380, 180, 30);
        add(l8);
        t2.setBounds(350, 380, 320, 30);
        add(t2);

        b.setBounds(570, 500, 100, 30);
        b.setBackground(new Color(33, 64, 128));
        add(b);
       

        b.addActionListener(this);

       
        getContentPane().setBackground(new Color(245, 245, 250));

        setSize(750, 580);
        setLocation(240, 60);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        String religion = (String) c1.getSelectedItem();
        String category = (String) c2.getSelectedItem();
        String income = (String) c3.getSelectedItem();
        String education = (String) c4.getSelectedItem();
        String occupation = (String) c5.getSelectedItem();

        String pan = t1.getText();
        String aadhar = t2.getText();

        Random ran = new Random();
        long first7 = (ran.nextLong() % 90000000L) + 3159001000000L;
        String acno = "" + Math.abs(first7);
        String ifsc = "UBIN03159";

        try {
            if (t2.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Fill all the required fields");
            } else {
                Conn sqlc = new Conn();
                String q1 = "insert into signuptwo values('" + formno + "','" + religion + "','" + category + "','" + income + "','" + education + "','" + occupation + "','" + pan + "','" + aadhar + "')";
                String q2 = "insert into accountdetails values('" + formno + "','" + acno + "','" + ifsc + "','" + name + "')";

                sqlc.s.executeUpdate(q1);
                sqlc.s.executeUpdate(q2);

                JOptionPane.showMessageDialog(null, "Account Holder Name: " + name + "\nAccount Number: " + acno + "\nIFSC Code: " + ifsc, "Account Created", JOptionPane.INFORMATION_MESSAGE);

                new Bankhome("").setVisible(true);
                setVisible(false);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Signup2("", "").setVisible(true);
    }
}
