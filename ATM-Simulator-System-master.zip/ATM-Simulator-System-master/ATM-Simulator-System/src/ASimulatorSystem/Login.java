package ASimulatorSystem;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import java.sql.*;
import java.text.SimpleDateFormat;

public class Login extends JFrame implements ActionListener {

    private JTextField tfCard;
    private JPasswordField pfPin;
    private JButton btnSignIn, btnClear, btnSignUp;
    private JPanel glassCard;
    String acno;

    public Login() {
        setTitle("ATM Portal - Secure Login");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setUndecorated(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        GradientPanel background = new GradientPanel();
        setContentPane(background);
        background.setLayout(null);

        initUI(background);
        setVisible(true);
    }

    private void initUI(JPanel panel) {

        ImageIcon logoIcon = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/bankicon.png"));
        Image scaledImage = logoIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
        JLabel logo = new JLabel(new ImageIcon(scaledImage));
        logo.setBounds(400, 30, 100, 100);
        panel.add(logo);

        Timer bounce = new Timer(10, new ActionListener() {
            int y = 30;
            int direction = -1;

            public void actionPerformed(ActionEvent e) {
                y += direction;
                if (y <= 20 || y >= 30) {
                    direction *= -1;
                }
                logo.setLocation(400, y);
            }
        });
        bounce.start();

        glassCard = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setColor(new Color(255, 255, 255, 80));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                super.paintComponent(g);
            }
        };
        glassCard.setOpaque(false);
        glassCard.setLayout(null);
        glassCard.setBounds(250, 160, 400, 350);
        glassCard.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 120), 2));
        panel.add(glassCard);

        JLabel lblTitle = new JLabel("ATM Login");
        lblTitle.setFont(new Font("Segoe UI Black", Font.BOLD, 28));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(135, 20, 200, 40);
        glassCard.add(lblTitle);

        JLabel lblCard = new JLabel("Card Number:");
        lblCard.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblCard.setForeground(Color.WHITE);
        lblCard.setBounds(40, 80, 150, 25);
        glassCard.add(lblCard);

        tfCard = new JTextField();
        tfCard.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        tfCard.setBounds(40, 110, 320, 30);
        tfCard.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        glassCard.add(tfCard);

        JLabel lblPin = new JLabel("PIN:");
        lblPin.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblPin.setForeground(Color.WHITE);
        lblPin.setBounds(40, 150, 100, 25);
        glassCard.add(lblPin);

        pfPin = new JPasswordField();
        pfPin.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        pfPin.setBounds(40, 180, 320, 30);
        pfPin.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        glassCard.add(pfPin);

        btnSignIn = createButton("SIGN IN", new Color(34, 139, 34));
        btnSignIn.setBounds(40, 230, 140, 40);
        glassCard.add(btnSignIn);

        btnClear = createButton("CLEAR", new Color(220, 20, 60));
        btnClear.setBounds(220, 230, 140, 40);
        glassCard.add(btnClear);

        btnSignUp = createButton("SIGN UP", new Color(0, 102, 204));
        btnSignUp.setBounds(40, 290, 320, 40);
        glassCard.add(btnSignUp);

        btnSignIn.addActionListener(this);
        btnClear.addActionListener(this);
        btnSignUp.addActionListener(this);
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI Semibold", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 100), 2));

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.darker());
            }

            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });

        return button;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
         try {
        if (e.getSource() == btnSignIn) {
            Conn c = new Conn();
            Date currentDate = new Date();  
            String card = tfCard.getText();
            String pin = new String(pfPin.getPassword());
            String q = "SELECT * FROM login WHERE cardnumber = '" + card + "' AND pin = '" + pin + "'";
            ResultSet rs = c.s.executeQuery(q);

            if (rs.next()) {
                acno = (rs.getString("acno"));
                String endDateStr = rs.getString("end");  

               
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
                java.util.Date expiryDateUtil = sdf.parse(endDateStr);

               
                java.sql.Date expiryDate = new java.sql.Date(expiryDateUtil.getTime());

                
                if (!currentDate.before(expiryDate)) {
                   
                    JOptionPane.showMessageDialog(this, "Card Expired. Please contact the bank.", "Expired Card", JOptionPane.ERROR_MESSAGE);
                     
                }else {
                       
                        new Transactions(pin, acno).setVisible(true);
                        setVisible(false);
                    }
                } else {
                    
                    JOptionPane.showMessageDialog(this, "Incorrect Card Number or PIN", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            } else if (e.getSource() == btnClear) {
               
                tfCard.setText("");
                pfPin.setText("");
            } else if (e.getSource() == btnSignUp) {
                
                setVisible(false);
                new adlogin().setVisible(true);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::new);
    }

    class GradientPanel extends JPanel {

        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            GradientPaint gp = new GradientPaint(0, 0, new Color(10, 24, 61), 0, getHeight(), new Color(0, 212, 255));
            g2.setPaint(gp);
            g2.fillRect(0, 0, getWidth(), getHeight());
        }
    }
}
