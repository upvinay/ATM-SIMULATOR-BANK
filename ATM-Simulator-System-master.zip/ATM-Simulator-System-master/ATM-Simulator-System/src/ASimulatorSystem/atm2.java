package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.text.SimpleDateFormat;
import com.toedter.calendar.JDateChooser;

public class atm2 extends JFrame implements ActionListener {

    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, n, ac, ng1, acg1;
    JButton b1, b2;
    String acno, ac1, start, end;
    JDateChooser dateChooser, dateChooser1;

    atm2(String ac1) {
        setTitle(" ATM APPLICATION ");
        getContentPane().setBackground(Color.DARK_GRAY);
        setLayout(null);
        l3 = new JLabel("  APPLICATION FORM FOR THE ATM CARD  ");
        l3.setFont(new Font("Osward", Font.BOLD, 26));
        l3.setForeground(Color.GREEN);
        l3.setBounds(120, 5, 600, 38);
        add(l3);

        this.ac1 = ac1;

        l1 = new JLabel("  CARD DETAILS ");
        l1.setFont(new Font("Times New Roman", Font.BOLD, 22));
        l1.setForeground(Color.ORANGE);
        l1.setBounds(320, 55, 600, 38);
        add(l1);
        ac = new JLabel("Account Number : ");
        ac.setFont(new Font("Osward", Font.BOLD, 22));
        ac.setForeground(Color.white);
        ac.setBounds(135, 150, 700, 30);
        add(ac);

        l4 = new JLabel("CARD VALIDITY ( Start and Expired date ).");
        l4.setFont(new Font("Osward", Font.BOLD, 20));
        l4.setForeground(Color.orange);
        l4.setBounds(100, 190, 700, 26);
        add(l4);
        l12 = new JLabel("( It's Approx 7 years. )");
        l12.setFont(new Font("Osward", Font.BOLD, 10));
        l12.setForeground(Color.white);
        l12.setBounds(100, 220, 700, 10);
        add(l12);
        l10 = new JLabel("Valid From");
        l10.setFont(new Font("Osward", Font.BOLD, 20));
        l10.setForeground(Color.GREEN);
        l10.setBounds(80, 235, 700, 26);
        add(l10);
        l11 = new JLabel("Valid upto");
        l11.setFont(new Font("Osward", Font.BOLD, 20));
        l11.setForeground(Color.red);
        l11.setBounds(400, 235, 700, 26);
        add(l11);
        acg1 = new JLabel();
        acg1.setText(ac1);
        acg1.setFont(new Font("Osward", Font.BOLD, 22));
        acg1.setForeground(Color.white);
        acg1.setBounds(350, 150, 700, 30);
        add(acg1);
        l5 = new JLabel("(Your 16-digit Card number)");
        l5.setFont(new Font("Raleway", Font.BOLD, 12));
        l5.setForeground(Color.white);
        l6 = new JLabel("It is totally random 16 characters.");
        l6.setFont(new Font("Raleway", Font.BOLD, 12));
        l6.setForeground(Color.white);
        l7 = new JLabel("PIN :( PIN IS RANDOM FOR NOW ) ");
        l7.setFont(new Font("Raleway", Font.BOLD, 18));
        l7.setForeground(Color.white);
        l8 = new JLabel("XXXX ( You Can Change pin while Transaction...) ");
        l8.setFont(new Font("Raleway", Font.BOLD, 18));
        l8.setForeground(Color.white);
        l9 = new JLabel("(4-digit password)");
        l9.setFont(new Font("Raleway", Font.BOLD, 12));
        l9.setForeground(Color.white);
        b1 = new JButton("Submit");
        b1.setFont(new Font("Raleway", Font.BOLD, 14));
        b1.setBackground(Color.orange);
        b1.setForeground(Color.WHITE);

        b2 = new JButton("Cancel");
        b2.setFont(new Font("Raleway", Font.BOLD, 14));
        b2.setBackground(Color.ORANGE);
        b2.setForeground(Color.WHITE);

        dateChooser = new JDateChooser();
        dateChooser.setForeground(new Color(105, 105, 105));
        dateChooser.setBounds(200, 240, 100, 20);
        add(dateChooser);
        dateChooser1 = new JDateChooser();
        dateChooser1.setForeground(new Color(105, 105, 105));
        dateChooser1.setBounds(500, 240, 100, 20);
        add(dateChooser1);

        l5.setBounds(100, 270, 200, 20);
        add(l5);

        l6.setBounds(330, 270, 500, 20);
        add(l6);

        l7.setBounds(100, 300, 400, 30);
        add(l7);
        l8.setBounds(100, 350, 500, 30);
        add(l8);

        l9.setBounds(100, 330, 200, 15);
        add(l9);

        b1.setBounds(250, 400, 100, 30);
        add(b1);

        b2.setBounds(420, 400, 100, 30);
        add(b2);

        b1.addActionListener(this);
        b2.addActionListener(this);

        setSize(800, 500);
        setLocation(240, 60);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        Random ran = new Random();
        long first7 = (ran.nextLong() % 90000000L) + 5040936000000000L;
        String cardno = "" + Math.abs(first7);

        long first3 = (ran.nextLong() % 9000L) + 1000L;
        String pin = "" + Math.abs(first3);
        String acno = ac1;

        Date st = dateChooser.getDate();
        Date en = dateChooser1.getDate();
        Date today = new Date(); 

        if (ae.getSource() == b2) {
            setVisible(false);
            new Bankhome("").setVisible(true);
        } else if (ae.getSource() == b1) {
            if (acno.equals("")) {
                JOptionPane.showMessageDialog(null, "Enter first Account number");
                return;
            }

            if (st == null || en == null) {
                JOptionPane.showMessageDialog(null, "Please select both start and end dates.");
                return;
            }

            
            if (st.before(today) || en.before(today)) {
                JOptionPane.showMessageDialog(null, "Dates must not be before today.");
                return;
            }

           
            Calendar cal = Calendar.getInstance();
            cal.setTime(st);
            cal.add(Calendar.YEAR, 2);
            Date minEndDate = cal.getTime();

            if (en.before(minEndDate)) {
                JOptionPane.showMessageDialog(null, "End date must be at least 2 years after the start date.");
                return;
            }

            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String start = sdf.format(st);
                String end = sdf.format(en);

                Conn sqlc = new Conn();
                String q2 = "insert into login values('" + acno + "','" + cardno + "','" + pin + "','" + start + "','" + end + "')";
                sqlc.s.executeUpdate(q2);

                JOptionPane.showMessageDialog(null, "Card Number: " + cardno + "\n Pin: " + pin);
                setVisible(false);
                new Bankhome("").setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new atm2("").setVisible(true);
    }

}
