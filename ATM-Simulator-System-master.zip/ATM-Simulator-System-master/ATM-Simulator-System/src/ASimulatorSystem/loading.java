package ASimulatorSystem;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class loading extends JFrame implements Runnable {

	private JPanel contentPane;
	private JProgressBar progressBar;
	Connection conn;
        String username;
	int s;
	Thread th;

	public static void main(String[] args) {
            new loading().setVisible(true);
	}

	public void setUploading() {
            setVisible(false);
            th.start();
	}

	public void run() {
            try {
                for (int i = 0; i < 200; i++) {
                    s = s + 1;
                    int m = progressBar.getMaximum();
                    int v = progressBar.getValue();
                    if (v < m) {
                        progressBar.setValue(progressBar.getValue() + 1);
                    } else {
                        i = 201;
                        setVisible(false);
                        new Bankhome("").setVisible(true);
                    }
                    Thread.sleep(20);
                }
            } catch (Exception e) {
		e.printStackTrace();
            }
	}

	public loading() {
            th = new Thread((Runnable) this);

            setBounds(350, 180, 600, 400);
            contentPane = new JPanel();
            contentPane.setBackground(Color.DARK_GRAY);
            setContentPane(contentPane);
            contentPane.setLayout(null);

            JLabel pr = new JLabel("Welcome To Bank Services ");
            pr.setForeground(Color.BLUE);
            pr.setFont(new Font("Trebuchet MS", Font.BOLD, 35));
            pr.setBounds(80,120, 700, 35);
            contentPane.add(pr);
	
            progressBar = new JProgressBar();
            progressBar.setFont(new Font("Tahoma", Font.BOLD, 12));
            progressBar.setStringPainted(true);
            progressBar.setBackground(Color.gray);
            progressBar.setForeground(Color.ORANGE);
            progressBar.setBounds(50, 205, 490, 25);
            contentPane.add(progressBar);

            JLabel lblNewLabel_2 = new JLabel("Please Wait....");
            lblNewLabel_2.setFont(new Font("Yu Gothic UI Semibold", Font.BOLD, 22));
            lblNewLabel_2.setForeground(new Color(160, 82, 45));
            lblNewLabel_2.setBounds(250, 250, 150, 22);
            contentPane.add(lblNewLabel_2);

            JPanel panel = new JPanel();
            panel.setBackground(Color.WHITE);
            panel.setBounds(10, 10, 580, 380);
            contentPane.add(panel);
              
            setUndecorated(true);
            setUploading();
	}
}