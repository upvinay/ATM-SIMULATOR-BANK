package ASimulatorSystem;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;

public class newCard extends JFrame implements ActionListener {

    JLabel l1, l3, l4, l5, l6, l7, l8, l9, l10, l11, l12, ac, acg1;
    JButton b1, b2;
    String acno;
    JDateChooser dateChooser, dateChooser1;

    public newCard(String acno) {
        this.acno = acno;

        setTitle("Re-New Application");
        getContentPane().setBackground(new Color(245, 245, 250));
        setLayout(null);

      
        l3 = new JLabel("  FORM FOR THE RE-NEW ATM CARD  ");
        l3.setFont(new Font("Osward", Font.BOLD, 26));
        l3.setForeground(Color.BLUE);
        l3.setBounds(130, 10, 600, 38);
        add(l3);

        l1 = new JLabel("  CARD DETAILS ");
        l1.setFont(new Font("Times New Roman", Font.BOLD, 22));
        l1.setForeground(Color.ORANGE);
        l1.setBounds(320, 55, 600, 38);
        add(l1);

        ac = new JLabel("Account Number : ");
        ac.setFont(new Font("Osward", Font.BOLD, 22));
        ac.setForeground(Color.black);
        ac.setBounds(135, 150, 700, 30);
        add(ac);

        acg1 = new JLabel(acno);
        acg1.setFont(new Font("Osward", Font.BOLD, 22));
        acg1.setForeground(Color.black);
        acg1.setBounds(350, 150, 700, 30);
        add(acg1);

        l4 = new JLabel("CARD VALIDITY ( Start and Expired date ).");
        l4.setFont(new Font("Osward", Font.BOLD, 20));
        l4.setForeground(Color.orange);
        l4.setBounds(100, 190, 700, 26);
        add(l4);

        l12 = new JLabel("( It's Approx 7 years. )");
        l12.setFont(new Font("Osward", Font.BOLD, 10));
        l12.setForeground(Color.black);
        l12.setBounds(100, 220, 700, 10);
        add(l12);

        l10 = new JLabel("Valid From");
        l10.setFont(new Font("Osward", Font.BOLD, 20));
        l10.setForeground(Color.GREEN);
        l10.setBounds(80, 235, 700, 26);
        add(l10);

        l11 = new JLabel("Valid Upto");
        l11.setFont(new Font("Osward", Font.BOLD, 20));
        l11.setForeground(Color.RED);
        l11.setBounds(400, 235, 700, 26);
        add(l11);

        dateChooser = new JDateChooser();
        dateChooser.setBounds(200, 240, 150, 20);
        add(dateChooser);

        dateChooser1 = new JDateChooser();
        dateChooser1.setBounds(500, 240, 150, 20);
        add(dateChooser1);

        l5 = new JLabel("(Your 16-digit Card number)");
        l5.setFont(new Font("Raleway", Font.BOLD, 12));
        l5.setForeground(Color.black);
        l5.setBounds(100, 270, 200, 20);
        add(l5);

        l6 = new JLabel("It is totally random 16 characters.");
        l6.setFont(new Font("Raleway", Font.BOLD, 12));
        l6.setForeground(Color.black);
        l6.setBounds(330, 270, 500, 20);
        add(l6);

        l7 = new JLabel("PIN :( PIN IS RANDOM FOR NOW ) ");
        l7.setFont(new Font("Raleway", Font.BOLD, 18));
        l7.setForeground(Color.black);
        l7.setBounds(100, 300, 400, 30);
        add(l7);

        l8 = new JLabel("XXXX ( You Can Change pin while Transaction...) ");
        l8.setFont(new Font("Raleway", Font.BOLD, 18));
        l8.setForeground(Color.black);
        l8.setBounds(100, 350, 500, 30);
        add(l8);

        l9 = new JLabel("(4-digit password)");
        l9.setFont(new Font("Raleway", Font.BOLD, 12));
        l9.setForeground(Color.black);
        l9.setBounds(100, 330, 200, 15);
        add(l9);

        b1 = new JButton("Submit");
        b1.setFont(new Font("Raleway", Font.BOLD, 14));
        b1.setBackground(Color.orange);
        b1.setForeground(Color.WHITE);
        b1.setBounds(250, 400, 100, 30);
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("Cancel");
        b2.setFont(new Font("Raleway", Font.BOLD, 14));
        b2.setBackground(Color.ORANGE);
        b2.setForeground(Color.WHITE);
        b2.setBounds(420, 400, 100, 30);
        b2.addActionListener(this);
        add(b2);

        setSize(800, 500);
        setLocation(240, 60);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b2) {
            setVisible(false);
            new Bankhome("").setVisible(true);
            return;
        }

        Date st = dateChooser.getDate();
        Date en = dateChooser1.getDate();

        if (st == null || en == null) {
            JOptionPane.showMessageDialog(null, "Please select both start and end dates.");
            return;
        }

        Date today = new Date();

       
        if (st.before(today)) {
            JOptionPane.showMessageDialog(null, "Start date cannot be before today's date.");
            return;
        }

    
        Calendar calStart = Calendar.getInstance();
        calStart.setTime(st);

        Calendar calEnd = Calendar.getInstance();
        calEnd.setTime(en);

        calStart.add(Calendar.YEAR, 2);
        if (calStart.after(calEnd)) {
            JOptionPane.showMessageDialog(null, "End date must be at least 2 years after the start date.");
            return;
        }

      
        Random ran = new Random();
        String cardno = "" + Math.abs((ran.nextLong() % 90000000L) + 5040936000000000L);
        String pin = "" + Math.abs((ran.nextLong() % 9000L) + 1000L);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String start = sdf.format(st);
        String end = sdf.format(en);

        try {
            Conn sqlc = new Conn();
            String q2 = "UPDATE login SET cardnumber = ?, pin = ?, start = ?, end = ? WHERE acno = ?";
            PreparedStatement ps = sqlc.c.prepareStatement(q2);
            ps.setString(1, cardno);
            ps.setString(2, pin);
            ps.setString(3, start);
            ps.setString(4, end);
            ps.setString(5, acno);

            int rowsUpdated = ps.executeUpdate();

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Card Number: " + cardno + "\nPin: " + pin);
                setVisible(false);
                new Bankhome("").setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Account number not found. Update failed.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating card details.");
        }
    }

    public static void main(String[] args) {
        new newCard("").setVisible(true);
    }
}
